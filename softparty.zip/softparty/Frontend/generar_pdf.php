<?php
require_once '../Config/db.php';

$placa = null;
if (isset($_POST['placa'])) $placa = $_POST['placa'];
if (isset($_GET['placa'])) $placa = $_GET['placa'];
if ($placa) {
    $sql = "SELECT * FROM facturas WHERE placa = '$placa' ORDER BY fecha_generacion DESC LIMIT 1";
    $result = $conn->query($sql);
    if ($row = $result->fetch_assoc()) {
        $facturaId = $row['id'];
        $archivo = $row['archivo_pdf'];
        $basePath = __DIR__ . '/../'; 
        if (!empty($archivo) && file_exists($basePath . $archivo)) {
         
            $fullPath = $basePath . $archivo;
            $ext = strtolower(pathinfo($fullPath, PATHINFO_EXTENSION));
            if ($ext === 'pdf') header('Content-Type: application/pdf');
            else header('Content-Type: text/html');
            header('Content-Disposition: attachment; filename="' . basename($fullPath) . '"');
            header('Content-Length: ' . filesize($fullPath));
            readfile($fullPath);
            exit;
        }

        
        $html = '<!doctype html><html><head><meta charset="utf-8"><title>Factura ' . htmlspecialchars($placa) . '</title>';
        $html .= '<style>
                body{font-family: Arial, sans-serif; color:#333;}
                .invoice-box{max-width:800px;margin:0 auto;padding:30px;border:1px solid #eee;box-shadow:0 0 10px rgba(0,0,0,0.05);}
                .invoice-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px}
                .company{font-size:18px;font-weight:700;color:#2c3e50}
                .meta{font-size:12px;color:#666}
                table{width:100%;border-collapse:collapse;margin-top:20px}
                table th{background:#f5f5f5;text-align:left;padding:8px;border-bottom:1px solid #ddd}
                table td{padding:8px;border-bottom:1px solid #eee}
                .total{font-weight:700}
                .right{text-align:right}
                .small{font-size:12px;color:#777}
            </style></head><body>';
        $html .= '<div class="invoice-box">'
                . '<div class="invoice-header">'
                    . '<div>'
                        . '<div class="company">Parqueadero - Factura</div>'
                        . '<div class="small">Fecha: ' . date('Y-m-d H:i:s') . '</div>'
                    . '</div>'
                    . '<div class="meta">' . '<strong>Factura para:</strong><br>'
                        . htmlspecialchars($row['nombre_propietario']) . '<br>' . htmlspecialchars($row['documento_identidad']) . '<br>' . htmlspecialchars($row['numero_contacto'])
                    . '</div>'
                . '</div>';
        $html .= '<div><strong>Placa:</strong> ' . htmlspecialchars($row['placa']) . ' &nbsp; <strong>Tipo:</strong> ' . htmlspecialchars($row['tipo_vehiculo']) . '</div>';
        $html .= '<table><thead><tr><th>Descripción</th><th class="right">Cantidad</th><th class="right">Precio</th><th class="right">Total</th></tr></thead><tbody>';
        $html .= '<tr><td>Tiempo en parqueadero (' . $row['tiempo_total'] . ' minutos)</td><td class="right">1</td><td class="right">$' . number_format($row['valor_pagar'],0,',','.') . '</td><td class="right">$' . number_format($row['valor_pagar'],0,',','.') . '</td></tr>';
        $html .= '</tbody><tfoot><tr><td></td><td></td><td class="total right">Total</td><td class="total right">$' . number_format($row['valor_pagar'],0,',','.') . '</td></tr></tfoot></table>';
        $html .= '<div class="small" style="margin-top:20px">Generado por Not Found Error 404 Roman Gomez</div>';
        $html .= '</div></body></html>';

       
        $autoload = __DIR__ . '/../vendor/autoload.php';
        if (!file_exists($autoload)) {
           
            http_response_code(500);
            echo '<!doctype html><html><head><meta charset="utf-8"><title>Error - PDF</title></head><body style="font-family:Arial,Helvetica,sans-serif; padding:30px;">';
            echo '<h2>Generación de PDF no disponible</h2>';
            echo '<p>La librería <strong>mPDF</strong> no está instalada. Para mostrar facturas en PDF instala las dependencias:</p>';
            echo '<pre style="background:#f5f5f7;padding:10px;border-radius:6px;">composer require mpdf/mpdf</pre>';
            echo '<p>Luego refresca esta operación. Si necesitas que genere PDF sin instalar dependencias, dime y lo preparo de otra forma.</p>';
            echo '<p><a href="../Frontend/historial.php">Volver al historial</a></p>';
            echo '</body></html>';
            exit;
        }
        require_once $autoload;
        if (!class_exists('\Mpdf\Mpdf')) {
            http_response_code(500);
            echo '<!doctype html><html><head><meta charset="utf-8"><title>Error - PDF</title></head><body style="font-family:Arial,Helvetica,sans-serif; padding:30px;">';
            echo '<h2>Generación de PDF no disponible</h2>';
            echo '<p>La clase <code>\Mpdf\Mpdf</code> no se encontró en el autoload. Ejecuta: <code>composer require mpdf/mpdf</code></p>';
            echo '<p><a href="../Frontend/historial.php">Volver al historial</a></p>';
            echo '</body></html>';
            exit;
        }

 
        try {
            $mpdf = new \Mpdf\Mpdf();
            $mpdf->WriteHTML($html);
            $pdfDirRel = 'Media/pdfs/';
            $pdfDirFull = $basePath . $pdfDirRel;
            if (!is_dir($pdfDirFull)) mkdir($pdfDirFull, 0755, true);
            $random = bin2hex(random_bytes(8));
            $fileName = "factura_{$placa}_{$random}.pdf";
            $saveRel = $pdfDirRel . $fileName;
            $saveFull = $pdfDirFull . $fileName;
            $mpdf->Output($saveFull, \Mpdf\Output\Destination::FILE);
            // Actualizar DB con ruta relativa
            $safePath = $conn->real_escape_string($saveRel);
            $update = "UPDATE facturas SET archivo_pdf = '$safePath' WHERE id = $facturaId";
            $conn->query($update);
   
            header('Content-Type: application/pdf');
            header('Content-Disposition: inline; filename="' . $fileName . '"');
            header('Content-Length: ' . filesize($saveFull));
            readfile($saveFull);
            exit;
        } catch (\Throwable $e) {
            http_response_code(500);
            echo '<!doctype html><html><head><meta charset="utf-8"><title>Error - PDF</title></head><body style="font-family:Arial,Helvetica,sans-serif; padding:30px;">';
            echo '<h2>Error generando PDF</h2>';
            echo '<pre style="background:#f8f8f8;padding:10px;border-radius:6px;">' . htmlspecialchars($e->getMessage()) . '</pre>';
            echo '<p><a href="../Frontend/historial.php">Volver al historial</a></p>';
            echo '</body></html>';
            exit;
        }
    } else {
        echo 'No se encontró registro de factura para esa placa.';
    }
} else {
    echo 'Solicitud inválida.';
}
?>
