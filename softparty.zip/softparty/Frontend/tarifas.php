<?php
require_once '../Config/db.php';

$msg = '';
if (isset($_GET['success']) && $_GET['success'] == '1') $msg = 'Acción realizada correctamente.';

$sql = "SELECT * FROM tarifas ORDER BY id DESC";
$res = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Tarifas</title>
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;800&display=swap" rel="stylesheet">
</head>
<body style="font-family:Nunito,Arial,Helvetica,sans-serif;background:#f3f6fb;">
  <div style="display:flex;min-height:100vh;">
    <div style="width:250px;background:#fff;padding:30px;box-shadow:2px 0 10px rgba(0,0,0,0.06)">
      <h2 style="color:#2b6cb0">Parqueadero</h2>
      <button onclick="window.location.href='../index.php'" style="width:100%;padding:10px;border-radius:8px;border:none;background:#2b6cb0;color:#fff;margin-top:12px;cursor:pointer">Ingreso</button>
      <button onclick="window.location.href='historial.php'" style="width:100%;padding:10px;border-radius:8px;border:none;background:#6b7280;color:#fff;margin-top:8px;cursor:pointer">Historial</button>
      <button onclick="window.location.href='tarifas.php'" style="width:100%;padding:10px;border-radius:8px;border:none;background:#10b981;color:#fff;margin-top:8px;cursor:pointer">Tarifas</button>
    </div>
    <div style="flex:1;padding:28px;">
      <div style="max-width:900px;margin:0 auto;">
        <h1>Administrar tarifas</h1>
        <?php if($msg): ?>
          <div style="background:#ecfdf5;border:1px solid #bbf7d0;padding:10px;border-radius:8px;color:#065f46;margin-bottom:12px"><?php echo $msg; ?></div>
        <?php endif; ?>

        <div style="background:#fff;padding:16px;border-radius:10px;box-shadow:0 4px 18px rgba(11,22,45,0.04);margin-bottom:18px;">
          <h3>Crear tarifa</h3>
          <form method="post" action="../Backend/tarifas_crud.php">
            <input type="hidden" name="accion" value="crear">
            <div style="display:flex;gap:10px;align-items:center;">
              <select name="tipo_vehiculo" required style="padding:8px;border-radius:8px;border:1px solid #e6edf3;">
                <option value="carro">Carro</option>
                <option value="moto">Moto</option>
                <option value="otro">Otro</option>
              </select>
              <input type="number" name="valor_hora" placeholder="Valor por hora" required style="padding:8px;border-radius:8px;border:1px solid #e6edf3;">
              <button type="submit" style="padding:8px 12px;border-radius:8px;border:none;background:#10b981;color:#fff;cursor:pointer">Crear</button>
            </div>
          </form>
        </div>

        <div style="background:#fff;padding:12px;border-radius:10px;box-shadow:0 4px 18px rgba(11,22,45,0.04);">
          <h3>Lista de tarifas</h3>
          <div style="overflow:auto;">
            <table style="width:100%;border-collapse:collapse;margin-top:10px;">
              <thead>
                <tr style="background:#f8fafc;text-align:left;"><th style="padding:10px">ID</th><th>Tipo</th><th>Valor/Hora</th><th style="width:200px">Acciones</th></tr>
              </thead>
              <tbody>
                <?php while($t = $res->fetch_assoc()): ?>
                <tr>
                  <form method="post" action="../Backend/tarifas_crud.php">
                    <input type="hidden" name="id" value="<?php echo $t['id']; ?>">
                    <td style="padding:10px;vertical-align:middle"><?php echo $t['id']; ?></td>
                    <td style="vertical-align:middle">
                      <select name="tipo_vehiculo" style="padding:6px;border-radius:6px;border:1px solid #e6edf3">
                        <option value="carro" <?php if($t['tipo_vehiculo']=='carro') echo 'selected'; ?>>Carro</option>
                        <option value="moto" <?php if($t['tipo_vehiculo']=='moto') echo 'selected'; ?>>Moto</option>
                        <option value="otro" <?php if($t['tipo_vehiculo']=='otro') echo 'selected'; ?>>Otro</option>
                      </select>
                    </td>
                    <td style="vertical-align:middle"><input type="number" name="valor_hora" value="<?php echo $t['valor_hora']; ?>" style="padding:6px;border-radius:6px;border:1px solid #e6edf3"></td>
                    <td style="vertical-align:middle">
                      <button type="submit" name="accion" value="editar" style="padding:6px 10px;border-radius:6px;border:none;background:#2563eb;color:#fff;cursor:pointer">Guardar</button>
                      <button type="submit" name="accion" value="eliminar" onclick="return confirm('Eliminar tarifa?')" style="padding:6px 10px;border-radius:6px;border:none;background:#ef4444;color:#fff;cursor:pointer;margin-left:8px">Borrar</button>
                    </td>
                  </form>
                </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
