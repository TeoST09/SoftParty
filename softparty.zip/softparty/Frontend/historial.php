<?php
require_once '../Config/db.php';


$nombre = isset($_GET['nombre']) ? $_GET['nombre'] : '';
$documento = isset($_GET['documento']) ? $_GET['documento'] : '';
$placa = isset($_GET['placa']) ? $_GET['placa'] : '';
$fecha = isset($_GET['fecha']) ? $_GET['fecha'] : '';
$estado = isset($_GET['estado']) ? $_GET['estado'] : '1';


$where = [];
if ($nombre) $where[] = "pr.nombre LIKE '%$nombre%'";
if ($documento) $where[] = "pr.documento_identidad LIKE '%$documento%'";
if ($placa) $where[] = "v.placa LIKE '%$placa%'";
if ($fecha) $where[] = "DATE(p.hora_entrada) = '$fecha'";
$where[] = "p.estado = $estado";
$where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$sql = "SELECT p.id, pr.nombre, pr.documento_identidad, pr.numero_contacto, v.placa, v.tipo_vehiculo, p.hora_entrada, p.hora_salida, p.tiempo_total, p.valor_pagar, p.estado
FROM parqueos p
JOIN vehiculos v ON p.vehiculo_id = v.id
JOIN propietarios pr ON v.propietario_id = pr.id
$where_sql
ORDER BY p.hora_entrada DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Historial Parqueadero</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;800&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        /* Reset y tipografía */
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'Nunito',sans-serif;background:linear-gradient(180deg,#f3f6fb 0%, #eef2f7 100%);color:#0f172a;min-height:100vh;display:flex;flex-direction:column}
        a{color:inherit;text-decoration:none}

        /* Layout */
        .app {
            display: grid;
            grid-template-columns: 260px 1fr;
            gap: 24px;
            max-width:1200px;
            margin:28px auto;
            width: calc(100% - 48px);
        }

        /* Sidebar */
        .sidebar {
            background:linear-gradient(180deg,#ffffff,#f7fbff);
            border-radius:14px;
            padding:22px;
            box-shadow:0 8px 30px rgba(2,6,23,0.06);
            display:flex;
            flex-direction:column;
            gap:12px;
            height:fit-content;
            align-self:start;
        }
        .brand {
            display:flex;gap:12px;align-items:center;
        }
        .brand h2{color:#134e8a;font-size:20px;font-weight:800}
        .nav-button { display:flex; gap:10px; align-items:center; padding:10px 12px; border-radius:10px; background:#eff6ff; color:#0f172a; border:1px solid #e6eef9; cursor:pointer; font-weight:600; transition:all .15s; }
        .nav-button:hover{transform:translateY(-2px);box-shadow:0 6px 18px rgba(35,79,122,0.08)}
        .nav-button.primary{background:#2b6cb0;color:#fff;border:none}
        .nav-button .fa{width:18px;text-align:center}

        /* Main */
        .main {
            display:flex;
            flex-direction:column;
            gap:18px;
        }
        .header {
            display:flex;
            justify-content:space-between;
            align-items:center;
            gap:12px;
        }
        .title { font-size:20px; font-weight:800; color:#07203a; }
        .card { background:#fff; padding:16px; border-radius:12px; box-shadow:0 8px 30px rgba(2,6,23,0.04) }

        /* Filtros */
        .filters { display:flex; gap:10px; flex-wrap:wrap; align-items:center }
        .filters .field { display:flex; flex-direction:column; gap:6px; }
        .filters input[type="text"], .filters input[type="date"], .filters select {
            padding:10px 12px; border-radius:10px; border:1px solid #e6eef9; background:#fbfdff; min-width:160px;
            outline:none; font-size:14px;
        }
        .filters button[type="submit"]{ padding:10px 14px; border-radius:10px; border:none; background:#2b6cb0; color:#fff; font-weight:700; cursor:pointer }
        .filters .small { font-size:12px; color:#475569 }

        /* Tabla */
        .table-wrap{ overflow:auto; border-radius:10px }
        table { width:100%; border-collapse:collapse; min-width:900px; }
        th, td { padding:12px 14px; text-align:left; border-bottom:1px solid #f1f5f9; font-size:14px }
        thead th { background:linear-gradient(90deg,#f8fafc,#f1f5f9); color:#0f172a; font-weight:700; position:sticky; top:0; z-index:1 }
        tbody tr:hover { background:linear-gradient(90deg, rgba(43,108,176,0.04), rgba(16,185,129,0.01)) }
        .badge { display:inline-block; padding:6px 10px; border-radius:999px; font-weight:700; font-size:12px; color:#fff }
        .badge.activo { background:#16a34a }
        .badge.finalizado { background:#6b7280 }

        /* Buttons en tabla */
        .action-btn { padding:8px 10px; border-radius:8px; border:none; font-weight:700; cursor:pointer }
        .action-btn.primary { background:#2563eb; color:#fff }
        .action-btn.ghost { background:transparent; border:1px solid #e6eef9; color:#0f172a }

        .muted { color:#6b7280; font-size:13px }

        /* Modales */
        .modal-backdrop{ display:none; position:fixed; inset:0; background:rgba(2,6,23,0.45); align-items:center; justify-content:center; padding:20px; z-index:50 }
        .modal{ background:#fff; border-radius:12px; padding:20px; width:100%; max-width:520px; box-shadow:0 20px 50px rgba(2,6,23,0.25); transform:translateY(6px); animation:pop .15s ease both }
        @keyframes pop { from { transform:translateY(18px); opacity:0 } to { transform:translateY(0); opacity:1 } }
        .modal h2{ font-size:18px; margin-bottom:8px }
        .modal .row{ display:flex; gap:8px; margin-top:10px }
        .modal input[type="datetime-local"]{ width:100%; padding:10px 12px; border-radius:8px; border:1px solid #e6eef9 }
        .modal .actions{ display:flex; gap:10px; justify-content:flex-end; margin-top:14px }

        /* PDF iframe */
        #pdfFrame{ width:100%; height:420px; border-radius:8px; border:1px solid #e6eef9 }

        /* Responsive */
        @media (max-width:1000px){
            .app{ grid-template-columns: 1fr; padding-bottom:40px }
            .sidebar{ order:2; display:flex; flex-direction:row; justify-content:space-around; width:100% }
            table{ min-width:800px }
        }
        @media (max-width:600px){
            th, td{ padding:10px }
            .filters input[type="text"], .filters input[type="date"], .filters select { min-width:120px }
        }
    </style>
</head>
<body>
    <div class="app">
        <aside class="sidebar card">
            <div class="brand">
                <div style="width:42px;height:42px;border-radius:10px;background:linear-gradient(180deg,#2b6cb0,#2563eb);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800">P</div>
                <div>
                    <h2>Parqueadero</h2>
                    <div class="small muted" style="font-size:13px;margin-top:4px">Control y facturación</div>
                </div>
            </div>

            <div style="margin-top:12px;display:flex;flex-direction:column;gap:8px">
                <button class="nav-button" onclick="window.location.href='../index.php'"><i class="fa fa-sign-in-alt"></i> Ingreso</button>
                <button class="nav-button primary" onclick="window.location.href='historial.php'"><i class="fa fa-history"></i> Historial</button>
                <button class="nav-button primary" onclick="window.location.href='tarifas.php'"><i class="fa fa-file-invoice"></i> Factura</button>
            </div>
        </aside>

        <main class="main">
            <div class="header">
                <div>
                    <div class="title">Historial de Parqueadero</div>
                    <div class="muted" style="margin-top:6px">Últimos registros — filtra y encuentra rápido</div>
                </div>
                <div style="display:flex;gap:10px;align-items:center">
                    <a class="nav-button ghost" href="../index.php"><i class="fa fa-arrow-left"></i> Volver</a>
                    <a class="nav-button primary" href="generar_reporte.php"><i class="fa fa-file-pdf"></i> Exportar</a>
                </div>
            </div>

            <div class="card">
                <form method="get" class="filters" style="margin-bottom:8px;">
                    <div class="field">
                        <label class="small muted">Nombre</label>
                        <input type="text" name="nombre" placeholder="Nombre" value="<?php echo htmlspecialchars($nombre); ?>">
                    </div>
                    <div class="field">
                        <label class="small muted">Documento</label>
                        <input type="text" name="documento" placeholder="Documento" value="<?php echo htmlspecialchars($documento); ?>">
                    </div>
                    <div class="field">
                        <label class="small muted">Placa</label>
                        <input type="text" name="placa" placeholder="Placa" value="<?php echo htmlspecialchars($placa); ?>">
                    </div>
                    <div class="field">
                        <label class="small muted">Fecha</label>
                        <input type="date" name="fecha" value="<?php echo htmlspecialchars($fecha); ?>">
                    </div>
                    <div class="field">
                        <label class="small muted">Estado</label>
                        <select name="estado">
                            <option value="1" <?php if($estado=='1') echo 'selected'; ?>>Activos</option>
                            <option value="0" <?php if($estado=='0') echo 'selected'; ?>>No activos</option>
                        </select>
                    </div>
                    <div style="display:flex;align-items:end">
                        <button type="submit">Buscar</button>
                    </div>
                </form>

                <div class="table-wrap" style="margin-top:8px;">
                    <table>
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Documento</th>
                                <th>Contacto</th>
                                <th>Placa</th>
                                <th>Tipo</th>
                                <th>Hora Entrada</th>
                                <th>Hora Salida</th>
                                <th>Tiempo Total</th>
                                <th>Valor Pagado</th>
                                <th>Estado</th>
                                <th style="text-align:center">Acción</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['nombre'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row['documento_identidad'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row['numero_contacto'] ?? '-'); ?></td>
                                <td style="font-weight:700;"><?php echo htmlspecialchars($row['placa'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row['tipo_vehiculo'] ?? '-'); ?></td>
                                <td><?php echo htmlspecialchars($row['hora_entrada'] ?? '-'); ?></td>
                                <td><?php echo htmlspecialchars($row['hora_salida'] ?? '-'); ?></td>
                                <td><?php echo $row['tiempo_total'] ? $row['tiempo_total'].' min' : '-'; ?></td>
                                <td><?php echo $row['valor_pagar'] ? '$'.$row['valor_pagar'] : '-'; ?></td>
                                <td>
                                    <?php if($row['estado'] == 1): ?>
                                        <span class="badge activo">Activo</span>
                                    <?php else: ?>
                                        <span class="badge finalizado">Finalizado</span>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align:center">
                                    <?php if($row['estado'] == 1): ?>
                                        <button type="button" class="action-btn primary" onclick="abrirModal('<?php echo htmlspecialchars($row['placa'] ?? ''); ?>', '<?php echo htmlspecialchars($row['hora_entrada'] ?? ''); ?>')">
                                            <i class="fa fa-receipt" style="margin-right:6px"></i> Facturar
                                        </button>
                                    <?php else: ?>
                                        <?php
                                            $placa = $row['placa'];
                                            $sql_fact = "SELECT archivo_pdf FROM facturas WHERE placa = '$placa' ORDER BY fecha_generacion DESC LIMIT 1";
                                            $res_fact = $conn->query($sql_fact);
                                            if ($res_fact && ($fact = $res_fact->fetch_assoc()) && !empty($fact['archivo_pdf']) && file_exists('../'.$fact['archivo_pdf'])) {
                                                echo '<a href="generar_pdf.php?placa=' . urlencode($placa) . '" target="_blank" class="nav-button ghost" style="padding:8px 10px"><i class="fa fa-file-pdf"></i> Ver factura</a>';
                                            } else {
                                                echo '<span class="muted">Sin factura</span>';
                                            }
                                        ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </main>
    </div>

    <div id="modalSalida" class="modal-backdrop">
        <div class="modal">
            <h2>Registrar Salida y Facturar</h2>
            <p class="muted" id="modalInfo">Placa: <strong id="modalPlacaText">-</strong></p>
            <form id="formSalida" method="post" action="../Backend/salida.php">
                <input type="hidden" id="modalPlaca" name="placa">
                <div class="row" style="margin-top:8px;">
                    <div style="flex:1">
                        <label class="small muted">Hora de salida</label>
                        <input class="form-input" type="datetime-local" id="modalHoraSalida" name="hora_salida" required>
                    </div>
                </div>
                <div class="actions">
                    <button type="button" class="nav-button ghost" onclick="cerrarModal()">Cancelar</button>
                    <button type="submit" class="nav-button primary">Confirmar salida</button>
                </div>
            </form>
        </div>
    </div>

    <div id="pdfModal" class="modal-backdrop">
        <div class="modal">
            <h2>Factura PDF</h2>
            <iframe id="pdfFrame" src="" frameborder="0"></iframe>
            <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px">
                <a id="pdfDownload" href="#" download class="nav-button primary"><i class="fa fa-download"></i> Descargar</a>
                <button id="pdfPrint" type="button" class="nav-button ghost">Imprimir</button>
                <button type="button" class="nav-button" onclick="cerrarPdfModal()">Cerrar</button>
            </div>
        </div>
    </div>

<script>

    function abrirModal(placa, horaEntrada) {
        document.getElementById('modalSalida').style.display = 'flex';
        document.getElementById('modalPlaca').value = placa;
        document.getElementById('modalPlacaText').textContent = placa || '-';


        var now = new Date();
        var tzoffset = now.getTimezoneOffset() * 60000;
        var localISOTime = (new Date(now - tzoffset)).toISOString().slice(0,16);
        document.getElementById('modalHoraSalida').value = localISOTime;
    }
    function cerrarModal() {
        document.getElementById('modalSalida').style.display = 'none';
    }

 
    function abrirPdf(url) {
        document.getElementById('pdfFrame').src = url;
        document.getElementById('pdfDownload').href = url;
        document.getElementById('pdfModal').style.display = 'flex';
    }
    function cerrarPdfModal() {
        document.getElementById('pdfModal').style.display = 'none';
        document.getElementById('pdfFrame').src = '';
  
        window.location.reload();
    }

    
    document.getElementById('formSalida').addEventListener('submit', function(e){
        if(!confirm('¿Está seguro de registrar la salida y generar la factura?')) {
            e.preventDefault();
            return false;
        }
       
    });

    document.querySelectorAll('.modal-backdrop').forEach(function(back){
        back.addEventListener('click', function(e){
            if(e.target === back){
                back.style.display = 'none';
                if(back.id === 'pdfModal'){
                    document.getElementById('pdfFrame').src = '';
                }
            }
        });
    });


</script>
</body>
</html>
