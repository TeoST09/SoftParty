CREATE DATABASE IF NOT EXISTS softparty;
USE softparty;

CREATE TABLE IF NOT EXISTS propietarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    documento_identidad VARCHAR(30) NOT NULL,
    numero_contacto VARCHAR(20) NOT NULL
);


CREATE TABLE IF NOT EXISTS vehiculos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    placa VARCHAR(20) NOT NULL UNIQUE,
    tipo_vehiculo ENUM('carro', 'moto', 'otro') NOT NULL,
    propietario_id INT NOT NULL,
    FOREIGN KEY (propietario_id) REFERENCES propietarios(id)
);

-- Tabla de parqueos
CREATE TABLE IF NOT EXISTS parqueos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vehiculo_id INT NOT NULL,
    hora_entrada DATETIME NOT NULL,
    hora_salida DATETIME DEFAULT NULL,
    tiempo_total INT DEFAULT 0, -- minutos
    valor_pagar DECIMAL(10,2) DEFAULT 0,
    estado INT(100) NOT NULL DEFAULT 1, 
    FOREIGN KEY (vehiculo_id) REFERENCES vehiculos(id)
);

-- Tabla de facturas
CREATE TABLE IF NOT EXISTS facturas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre_propietario VARCHAR(100) NOT NULL,
    documento_identidad VARCHAR(30) NOT NULL,
    numero_contacto VARCHAR(20) NOT NULL,
    placa VARCHAR(20) NOT NULL,
    tipo_vehiculo ENUM('carro', 'moto', 'otro') NOT NULL,
    hora_entrada DATETIME NOT NULL,
    hora_salida DATETIME NOT NULL,
    tiempo_total INT NOT NULL,
    valor_pagar DECIMAL(10,2) NOT NULL,
    fecha_generacion DATETIME NOT NULL,
    archivo_pdf VARCHAR(255)
);

-- Tabla de tarifas
CREATE TABLE IF NOT EXISTS tarifas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo_vehiculo ENUM('carro', 'moto', 'otro') NOT NULL,
    valor_hora DECIMAL(10,2) NOT NULL
);