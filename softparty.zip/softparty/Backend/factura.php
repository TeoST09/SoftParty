<?php
require_once '../Config/db.php';

if (!isset($_GET['placa'])) {
    echo 'Placa no especificada.';
    exit;
}
$placa = $_GET['placa'];

$sql = "SELECT p.hora_entrada, p.hora_salida, p.tiempo_total, p.valor_pagar, v.placa, v.tipo_vehiculo, pr.nombre, pr.documento_identidad, pr.numero_contacto FROM parqueos p JOIN vehiculos v ON p.vehiculo_id = v.id JOIN propietarios pr ON v.propietario_id = pr.id WHERE v.placa = '$placa' AND p.hora_salida IS NOT NULL ORDER BY p.hora_salida DESC LIMIT 1";
$result = $conn->query($sql);
if ($row = $result->fetch_assoc()) {
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Factura PDF</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="factura">
        <h2>Factura Parqueadero</h2>
        <strong>Propietario:</strong> <?php echo $row['nombre']; ?><br>
        <strong>Documento de identidad:</strong> <?php echo $row['documento_identidad']; ?><br>
        <strong>Número de contacto:</strong> <?php echo $row['numero_contacto']; ?><br>
        <strong>Placa:</strong> <?php echo $row['placa']; ?><br>
        <strong>Tipo de vehículo:</strong> <?php echo $row['tipo_vehiculo']; ?><br>
        <strong>Hora de entrada:</strong> <?php echo $row['hora_entrada']; ?><br>
        <strong>Hora de salida:</strong> <?php echo $row['hora_salida']; ?><br>
        <strong>Tiempo total:</strong> <?php echo $row['tiempo_total']; ?> minutos<br>
        <strong>Valor a pagar:</strong> $<?php echo $row['valor_pagar']; ?><br>
        <form method="post" action="generar_pdf.php">
            <input type="hidden" name="placa" value="<?php echo $row['placa']; ?>">
            <button type="submit">Generar PDF</button>
        </form>
        <div style='margin-top:30px; font-size:0.9em; color:#888;'>Generado por Not Found Error 404 Roman Gomez</div>
    </div>
</body>
</html>
<?php
} else {
    echo 'No se encontró registro de salida para esa placa.';
}
?>
