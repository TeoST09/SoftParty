<?php
require_once '../Config/db.php';

class RegistroParqueadero {
    private $conn;
    public function __construct($conn) {
        $this->conn = $conn;
    }
    public function registrar($data) {
        $nombre = $data['nombre'];
        $documento = $data['documento'];
        $contacto = $data['contacto'];
        $placa = $data['placa'];
        $tipo = $data['tipo'];
        $hora_entrada = isset($data['hora_entrada']) ? date('Y-m-d H:i:s', strtotime($data['hora_entrada'])) : date('Y-m-d H:i:s');

    
        $sql_check_veh = "SELECT id FROM vehiculos WHERE placa = '$placa'";
        $result_check_veh = $this->conn->query($sql_check_veh);
        if ($result_check_veh && $row_veh = $result_check_veh->fetch_assoc()) {
            $veh_id = $row_veh['id'];
        } else {
        
            $sql_prop = "INSERT INTO propietarios (nombre, documento_identidad, numero_contacto) VALUES ('$nombre', '$documento', '$contacto')";
            $this->conn->query($sql_prop);
            $prop_id = $this->conn->insert_id;
            $sql_veh = "INSERT INTO vehiculos (placa, tipo_vehiculo, propietario_id) VALUES ('$placa', '$tipo', $prop_id)";
            $this->conn->query($sql_veh);
            $veh_id = $this->conn->insert_id;
        }
       
        $sql_parq = "INSERT INTO parqueos (vehiculo_id, hora_entrada, hora_salida, tiempo_total, valor_pagar, estado) VALUES ($veh_id, '$hora_entrada', NULL, 0, 0, 1)";
        $this->conn->query($sql_parq);
        return true;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once '../Config/db.php';
    $placa = $_POST['placa'];
   
    $sql_check = "SELECT p.estado FROM parqueos p JOIN vehiculos v ON p.vehiculo_id = v.id WHERE v.placa = '$placa' ORDER BY p.id DESC LIMIT 1";
    $res_check = $conn->query($sql_check);
    if ($res_check && $row = $res_check->fetch_assoc()) {
        if ($row['estado'] == 1) {
            echo '<script>alert("La placa ya está registrada y activa. No puede crearla nuevamente."); window.location.href = "../index.php";</script>';
            exit;
        } else if ($row['estado'] == 0) {
           
            $registro = new RegistroParqueadero($conn);
            $exito = $registro->registrar($_POST);
            if ($exito === true) {
                echo '<script>window.location.href = "../index.php?success=1";</script>';
                exit;
            } else {
                echo '<script>alert("Error en el registro"); window.history.back();</script>';
                exit;
            }
        }
    } else {
       
        $registro = new RegistroParqueadero($conn);
        $exito = $registro->registrar($_POST);
        if ($exito === true) {
            echo '<script>window.location.href = "../index.php?success=1";</script>';
            exit;
        } else {
            echo '<script>alert("Error en el registro"); window.history.back();</script>';
            exit;
        }
    }
}
?>
