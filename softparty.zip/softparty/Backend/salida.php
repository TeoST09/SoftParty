<?php
require_once '../Config/db.php';

class SalidaParqueadero {
    private $conn;
    public function __construct($conn) {
        $this->conn = $conn;
    }
    public function salida($placa, $hora_salida = null) {
  
        if (!empty($hora_salida)) {
          
            $hora_salida = str_replace('T', ' ', $hora_salida);
            $hora_salida = date('Y-m-d H:i:s', strtotime($hora_salida));
        } else {
            $hora_salida = date('Y-m-d H:i:s');
        }
        $sql = "SELECT p.id, p.hora_entrada, v.tipo_vehiculo, v.placa, pr.nombre, pr.documento_identidad, pr.numero_contacto FROM parqueos p JOIN vehiculos v ON p.vehiculo_id = v.id JOIN propietarios pr ON v.propietario_id = pr.id WHERE v.placa = '$placa' AND p.hora_salida IS NULL";
        $result = $this->conn->query($sql);
        if ($row = $result->fetch_assoc()) {
            $parqueo_id = $row['id'];
            $hora_entrada = $row['hora_entrada'];
            $tipo_vehiculo = $row['tipo_vehiculo'];
            $nombre = $row['nombre'];
            $documento = $row['documento_identidad'];
            $contacto = $row['numero_contacto'];

            $entrada = strtotime($hora_entrada);
            $salida = strtotime($hora_salida);
            $minutos = max(0, round(($salida - $entrada) / 60));
         
           
            $tipo_esc = $this->conn->real_escape_string($tipo_vehiculo);
            $sql_tarifa = "SELECT valor_hora FROM tarifas WHERE tipo_vehiculo = '$tipo_esc' LIMIT 1";
            $res_tarifa = $this->conn->query($sql_tarifa);
          
            $tarifa = 3000.0;
            if ($row_tarifa = $res_tarifa->fetch_assoc()) {
         
                $tarifa = floatval($row_tarifa['valor_hora']);
            }
          
            $full_hours = intdiv($minutos, 60);
            $remainder = $minutos % 60;
            $valor = $full_hours * $tarifa;
            if ($remainder > 0) {
                if ($remainder <= 30) {
                    $valor += round($tarifa / 2);
                } else {
                    $valor += $tarifa;
                }
            }
          
            if ($valor < 0) $valor = 0;

            $sql_up = "UPDATE parqueos SET hora_salida='$hora_salida', tiempo_total=$minutos, valor_pagar=$valor, estado=0 WHERE id=$parqueo_id";
            $this->conn->query($sql_up);

       
            $fecha_gen = date('Y-m-d H:i:s');
            $sql_fact = "INSERT INTO facturas (nombre_propietario, documento_identidad, numero_contacto, placa, tipo_vehiculo, hora_entrada, hora_salida, tiempo_total, valor_pagar, fecha_generacion, archivo_pdf) VALUES (
                '" . $this->conn->real_escape_string($nombre) . "', '" . $this->conn->real_escape_string($documento) . "', '" . $this->conn->real_escape_string($contacto) . "', '" . $this->conn->real_escape_string($placa) . "', '" . $this->conn->real_escape_string($tipo_vehiculo) . "', '" . $this->conn->real_escape_string($hora_entrada) . "', '" . $this->conn->real_escape_string($hora_salida) . "', $minutos, $valor, '" . $this->conn->real_escape_string($fecha_gen) . "', NULL)";
            $this->conn->query($sql_fact);
            $factura_id = $this->conn->insert_id;

           
            $pdf_file = null;
            $autoload = __DIR__ . '/../vendor/autoload.php';
            $basePath = __DIR__ . '/../';
            $pdfDirRel = 'Media/pdfs/';
            $pdfDirFull = $basePath . $pdfDirRel;
            if (!is_dir($pdfDirFull)) mkdir($pdfDirFull, 0755, true);
            $random = bin2hex(random_bytes(8));
          
            $html = '<!doctype html><html><head><meta charset="utf-8"><title>Factura ' . htmlspecialchars($placa) . '</title>';
            $html .= '<style>
                body{font-family: Arial, sans-serif; color:#333;}
                .invoice-box{max-width:800px;margin:0 auto;padding:30px;border:1px solid #eee;box-shadow:0 0 10px rgba(0,0,0,0.05);}
                .invoice-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px}
                .company{font-size:18px;font-weight:700;color:#2c3e50}
                .meta{font-size:12px;color:#666}
                table{width:100%;border-collapse:collapse;margin-top:20px}
                table th{background:#f5f5f5;text-align:left;padding:8px;border-bottom:1px solid #ddd}
                table td{padding:8px;border-bottom:1px solid #eee}
                .total{font-weight:700}
                .right{text-align:right}
                .small{font-size:12px;color:#777}
            </style></head><body>';
            $html .= '<div class="invoice-box">'
                . '<div class="invoice-header">'
                    . '<div>'
                        . '<div class="company">Parqueadero - Factura</div>'
                        . '<div class="small">Fecha: ' . date('Y-m-d H:i:s') . '</div>'
                    . '</div>'
                    . '<div class="meta">' . '<strong>Factura para:</strong><br>'
                        . htmlspecialchars($nombre) . '<br>' . htmlspecialchars($documento) . '<br>' . htmlspecialchars($contacto)
                    . '</div>'
                . '</div>';
            $html .= '<div><strong>Placa:</strong> ' . htmlspecialchars($placa) . ' &nbsp; <strong>Tipo:</strong> ' . htmlspecialchars($tipo_vehiculo) . '</div>';
            $html .= '<table><thead><tr><th>Descripción</th><th class="right">Cantidad</th><th class="right">Precio</th><th class="right">Total</th></tr></thead><tbody>';
            $html .= '<tr><td>Tiempo en parqueadero (' . $minutos . ' minutos)</td><td class="right">1</td><td class="right">$' . number_format($valor,0,',','.') . '</td><td class="right">$' . number_format($valor,0,',','.') . '</td></tr>';
            $html .= '</tbody><tfoot><tr><td></td><td></td><td class="total right">Total</td><td class="total right">$' . number_format($valor,0,',','.') . '</td></tr></tfoot></table>';
            $html .= '<div class="small" style="margin-top:20px">Generado por Not Found Error 404 Roman Gomez</div>';
            $html .= '</div></body></html>';

           
            if (file_exists($autoload)) {
                require_once $autoload;
                if (class_exists('\\Mpdf\\Mpdf')) {
                    try {
                        $mpdf = new \Mpdf\Mpdf();
                        $mpdf->WriteHTML($html);
                        $fileName = "factura_{$placa}_{$random}.pdf";
                        $saveRel = $pdfDirRel . $fileName;
                        $saveFull = $pdfDirFull . $fileName;
                        $mpdf->Output($saveFull, \Mpdf\Output\Destination::FILE);
                        $pdf_file = $saveRel;
                    } catch (\Throwable $e) {
                     
                        $pdf_file = null;
                    }
                }
            }
      
            if (!$pdf_file) {
                $fileName = "factura_{$placa}_{$random}.html";
                $saveRel = $pdfDirRel . $fileName;
                $saveFull = $pdfDirFull . $fileName;
                file_put_contents($saveFull, "<html><head><meta charset='utf-8'></head><body>$html</body></html>");
                $pdf_file = $saveRel;
            }

      
            $safePath = $this->conn->real_escape_string($pdf_file);
            $update = "UPDATE facturas SET archivo_pdf = '$safePath' WHERE id = $factura_id";
            $this->conn->query($update);

            return [
                'success' => true,
                'nombre' => $nombre,
                'documento' => $documento,
                'contacto' => $contacto,
                'placa' => $placa,
                'tipo_vehiculo' => $tipo_vehiculo,
                'hora_entrada' => $hora_entrada,
                'hora_salida' => $hora_salida,
                'minutos' => $minutos,
                'valor' => $valor,
                'pdf_url' => $pdf_file,
                'factura_id' => $factura_id
            ];
        } else {
            return ['success' => false, 'error' => 'No se encontró registro de entrada para esa placa.'];
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $salida = new SalidaParqueadero($conn);
    $hora_salida = isset($_POST['hora_salida']) ? $_POST['hora_salida'] : null;
    $result = $salida->salida($_POST['placa'], $hora_salida);

    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode($result);
        exit;
    }
    
    if ($result['success'] && !empty($result['pdf_url'])) {
        header('Location: ../Frontend/generar_pdf.php?placa=' . urlencode($result['placa']));
        exit;
    } else {
       
        $msg = isset($result['error']) ? $result['error'] : 'Error al procesar la salida.';
        echo '<script>alert("' . addslashes($msg) . '"); window.location.href = "../Frontend/historial.php";</script>';
        exit;
    }
}

?>
