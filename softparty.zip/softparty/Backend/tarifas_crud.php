<?php
require_once '../Config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = isset($_POST['accion']) ? $_POST['accion'] : '';
    if ($accion === 'crear') {
        $tipo = $_POST['tipo_vehiculo'];
        $valor = floatval($_POST['valor_hora']);
        $sql = "INSERT INTO tarifas (tipo_vehiculo, valor_hora) VALUES ('".$conn->real_escape_string($tipo)."', $valor)";
        $conn->query($sql);
        header('Location: ../Frontend/tarifas.php');
        exit;
    }
    if ($accion === 'editar') {
        $id = intval($_POST['id']);
        $tipo = $_POST['tipo_vehiculo'];
        $valor = floatval($_POST['valor_hora']);
        $sql = "UPDATE tarifas SET tipo_vehiculo='".$conn->real_escape_string($tipo)."', valor_hora=$valor WHERE id=$id";
        $conn->query($sql);
        header('Location: ../Frontend/tarifas.php');
        exit;
    }
    if ($accion === 'eliminar') {
        $id = intval($_POST['id']);
        $sql = "DELETE FROM tarifas WHERE id=$id";
        $conn->query($sql);
        header('Location: ../Frontend/tarifas.php');
        exit;
    }
}
?>
