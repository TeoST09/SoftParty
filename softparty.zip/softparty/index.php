<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema de Parqueadero</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;800&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'Nunito',sans-serif;background:linear-gradient(180deg,#f0f3f8,#eef2f7);min-height:100vh;display:flex;flex-direction:column}
        .layout{display:grid;grid-template-columns:250px 1fr;gap:24px;max-width:1200px;margin:28px auto;width:calc(100% - 48px)}
        .sidebar{background:#fff;border-radius:12px;padding:28px 18px;box-shadow:0 10px 30px rgba(2,6,23,0.06);display:flex;flex-direction:column;align-items:center;gap:18px}
        .brand{display:flex;gap:12px;align-items:center;width:100%}
        .brand .logo{width:46px;height:46px;border-radius:10px;background:linear-gradient(180deg,#2b6cb0,#2563eb);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800}
        .brand h2{color:#134e8a;font-size:18px;font-weight:800}
        .nav-button{width:100%;display:flex;gap:12px;align-items:center;padding:10px 12px;border-radius:10px;background:#2b6cb0;color:#fff;border:none;cursor:pointer;font-weight:700;transition:all .12s}
        .nav-button:hover{transform:translateY(-2px);box-shadow:0 8px 20px rgba(37,99,235,0.08)}
        .nav-button.ghost{background:transparent;color:#0f172a;border:1px solid #e8f0fb}
        .main{display:flex;flex-direction:column;gap:18px}
        .card{background:#fff;border-radius:14px;padding:32px;box-shadow:0 10px 30px rgba(2,6,23,0.04);max-width:640px;margin:0 auto}
        .title{font-size:20px;font-weight:800;color:#07203a;margin-bottom:6px}
        .muted{color:#6b7280}
        .register-form{display:flex;flex-direction:column;gap:16px}
        .form-group{display:flex;flex-direction:column;gap:6px}
        .form-label{font-weight:600;color:#334155;font-size:14px}
        .form-input{padding:10px 12px;border-radius:10px;border:1px solid #e6eef9;background:#fbfdff;font-size:14px;outline:none}
        .form-input:focus{border-color:#2b6cb0;background:#fff}
        .highlight{background:#eaf6ff;border-radius:10px;padding:12px;border:1px solid #dbeffd}
        .btn{padding:12px 14px;border-radius:10px;border:none;font-weight:800;cursor:pointer}
        .btn.primary{background:#2563eb;color:#fff}
        .note{font-size:13px;color:#475569;background:#f8fafc;padding:10px;border-radius:8px;border:1px solid #eef2f7}
        .link{color:#2563eb;text-decoration:none;font-weight:700;text-align:center;display:block}
        @media (max-width:900px){.layout{grid-template-columns:1fr;padding:12px}.sidebar{flex-direction:row;justify-content:space-around;padding:12px;height:auto}.brand h2{display:none}.card{padding:20px;width:100%}}
    </style>
</head>
<body>
    <div class="layout">
        <aside class="sidebar">
            <div class="brand" style="width:100%">
                <div class="logo">P</div>
                <div style="flex:1">
                    <h2>Mi Sitio</h2>
                    <div class="muted" style="font-size:13px;margin-top:4px">Control de parqueadero</div>
                </div>
            </div>
            <div style="width:100%;display:flex;flex-direction:column;gap:10px">
                <button class="nav-button" onclick="window.location.href='index.php'"><i class="fa fa-sign-in-alt"></i> Ingreso</button>
                <button class="nav-button ghost" onclick="window.location.href='Frontend/historial.php'"><i class="fa fa-history"></i> Historial</button>
                 <button class="nav-button ghost" onclick="window.location.href='Frontend/tarifas.php'"><i class="fa fa-history"></i> Factura</button>
            </div>
        </aside>

        <main class="main">
            <div class="card">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
                    <div>
                        <div class="title">Bienvenido</div>
                        <div class="muted" style="font-size:13px">Registra la entrada del vehículo</div>
                    </div>
                    <div style="text-align:right">
                        <a class="link" href="Frontend/historial.php">Ver historial</a>
                    </div>
                </div>

                <form id="form-registro" class="register-form" method="POST" action="Backend/registro.php">
                    <div class="form-group">
                        <label for="nombre" class="form-label">Nombre</label>
                        <input class="form-input" type="text" id="nombre" name="nombre" required>
                    </div>

                    <div class="form-group">
                        <label for="documento" class="form-label">Documento de identidad</label>
                        <input class="form-input" type="text" id="documento" name="documento" required>
                    </div>

                    <div class="form-group">
                        <label for="contacto" class="form-label">Teléfono</label>
                        <input class="form-input" type="text" id="contacto" name="contacto" required>
                    </div>

                    <div class="form-group">
                        <label for="placa" class="form-label">Placa</label>
                        <input class="form-input" type="text" id="placa" name="placa" required>
                    </div>

                    <div class="form-group">
                        <label for="tipo" class="form-label">Tipo de vehículo</label>
                        <select class="form-input" id="tipo" name="tipo" required>
                            <option value="carro">Carro</option>
                            <option value="moto">Moto</option>
                            <option value="otro">Otro</option>
                        </select>
                    </div>

                    <div class="form-group highlight">
                        <label for="hora_entrada" class="form-label" style="font-weight:800;color:#0b66cc">Hora de entrada <span style="color:#d62828">*</span></label>
                        <input class="form-input" type="datetime-local" id="hora_entrada" name="hora_entrada" required style="border:2px solid #007bff;background:#ffffff">
                        <small style="color:#475569">Selecciona la fecha y hora de ingreso del vehículo.</small>
                    </div>

                    <div class="form-group">
                        <input type="submit" id="boton" value="Registrar" class="btn primary">
                    </div>

                    <div class="form-group">
                        <a href="#" class="link">¿Ya estás registrado?</a>
                    </div>

                    <div class="form-group">
                        <div id="registro-msg" style="min-height:18px"></div>
                    </div>

                    <div style="margin-top:8px" class="note">
                        Para ver facturas en PDF instala mPDF ejecutando en PowerShell:
                        <pre style="margin-top:8px;background:#f4f6f8;padding:8px;border-radius:6px">composer require mpdf/mpdf</pre>
                    </div>
                </form>
            </div>
        </main>
    </div>

    <script>
        window.onload = function() {
            var now = new Date();
            var tzoffset = now.getTimezoneOffset() * 60000;
            var localISOTime = (new Date(now - tzoffset)).toISOString().slice(0,16);
            var he = document.getElementById('hora_entrada');
            if (he) he.value = localISOTime;
        }

        <?php if (isset($_GET['success']) && $_GET['success'] === '1'): ?>
        window.addEventListener('load', function(){
            alert('Registro realizado correctamente.');
            window.location.href = 'index.php';
        });
        <?php endif; ?>
    </script>
</body>
</html>
